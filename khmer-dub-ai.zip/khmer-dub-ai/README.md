# Khmer Dub AI 🇰🇭

កម្មវិធីដាក់វីដេអូនិយាយភាសាចិន → បានវីដេអូនិយាយភាសាខ្មែរ ដោយប្រើ AI ឥតគិតថ្លៃ។

*A free desktop tool that dubs Chinese-speaking videos into Khmer: speech recognition → translation → Khmer text-to-speech → merged video.*

## ដំណើរការ / How it works

1. **FFmpeg** ទាញសំឡេងចេញពីវីដេអូ
2. **faster-whisper** ស្តាប់ភាសាចិន ទៅជាអត្ថបទ + ម៉ោង (ដំណើរការក្នុងកុំព្យូទ័រ)
3. **deep-translator** (Google Translate) បកប្រែចិន → ខ្មែរ
4. **edge-tts** បង្កើតសំឡេងខ្មែរ (Sreymom / Piseth) តាមម៉ោងរឿង
5. **FFmpeg** ដាក់សំឡេងខ្មែរចូលវីដេអូ និងរក្សា subtitle ខ្មែរ (`.srt`)

## ការដំឡើង / Installation

ត្រូវការ **Python 3.10 – 3.13** (ណែនាំ **3.12**) និង **FFmpeg**។

```bash
# Windows: ដំឡើង FFmpeg
winget install ffmpeg

# ដំឡើងបណ្ណាល័យ Python
python -m pip install -r requirements.txt
```

> ⚠️ Python 3.14៖ `faster-whisper` (តាមរយៈ `ctranslate2`) អាចមិនទាន់មានកំណែរួចជាស្រេច។ បើដំឡើងមិនបាន សូមប្រើ Python 3.12។

## របៀបប្រើ / Usage

```bash
python khmer_dub_ai.py
```

1. ជ្រើសវីដេអូដែលនិយាយភាសាចិន
2. ជ្រើសសំឡេង AI ខ្មែរ និងម៉ូដែលស្តាប់ (`small` លឿន / `medium` ត្រឹមត្រូវជាង)
3. ជ្រើសថាលាយជាមួយសំឡេងដើម ឬជំនួសទាំងស្រុង
4. ចុច **ចាប់ផ្តើម** (ណែនាំឱ្យសាកល្បងរបៀប ២ នាទីដំបូងសិន)

លទ្ធផលរក្សាទុកក្បែរវីដេអូ៖ `*_khmer.mp4`, `*_khmer.mp3`, `*_khmer.srt`

## ដែនកំណត់ / Limitations

- គុណភាពអាស្រ័យលើការស្តាប់របស់ Whisper និងការបកប្រែរបស់ Google (ខ្មែរអាចមិនរលូន)
- សំឡេង AI តែមួយអានតួអង្គទាំងអស់ ហើយគ្មានអារម្មណ៍
- អត្ថបទខ្មែរវែងជាងចិន ដូច្នេះសំឡេងអាចអានលឿន (កំណត់ដោយ `MAX_SPEEDUP` ក្នុងកូដ)
- ត្រូវមានអ៊ីនធឺណិតសម្រាប់ការបកប្រែ និងសំឡេង
- `edge-tts` ប្រើសេវាអានឮរបស់ Microsoft Edge តាមមធ្យោបាយមិនផ្លូវការ ដូច្នេះអាចឈប់ដំណើរការនៅពេលណាមួយ
- ប្រើជាមួយវីដេអូដែលអ្នកមានសិទ្ធិប្រើប៉ុណ្ណោះ

## License

MIT — មើលឯកសារ `LICENSE`
