"""
Khmer Dub AI
ដាក់វីដេអូនិយាយភាសាចិន → បានវីដេអូនិយាយភាសាខ្មែរ (ឥតគិតថ្លៃទាំងអស់)

ជំហានដែលកម្មវិធីធ្វើដោយស្វ័យប្រវត្តិ៖
  1. ទាញសំឡេងចេញពីវីដេអូ                      (FFmpeg)
  2. ស្តាប់ភាសាចិន → អត្ថបទ + ម៉ោង              (Whisper / faster-whisper, ដំណើរការក្នុងកុំព្យូទ័រ)
  3. បកប្រែចិន → ខ្មែរ                          (Google Translate តាម deep-translator)
  4. អានអត្ថបទខ្មែរជាសំឡេង AI តាមម៉ោងរឿង       (Edge TTS)
  5. ដាក់សំឡេងខ្មែរចូលវីដេអូ + រក្សា subtitle ខ្មែរ (.srt)  (FFmpeg)

ត្រូវដំឡើងជាមុន៖
    pip install edge-tts pydub faster-whisper deep-translator
    (បើប្រើ Python 3.13 ឬថ្មីជាងនេះ បន្ថែម៖ pip install audioop-lts)
    និង FFmpeg  (Windows៖ winget install ffmpeg)
"""

import asyncio
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor, as_completed
from tkinter import filedialog, messagebox, ttk

try:
    import edge_tts
    from deep_translator import GoogleTranslator
    from faster_whisper import WhisperModel
    from pydub import AudioSegment
except ImportError as error:
    _root = tk.Tk()
    _root.withdraw()
    messagebox.showerror(
        "ខ្វះបណ្ណាល័យ",
        f"មានបញ្ហា: {error}\n\n"
        "សូមដំណើរការក្នុង Terminal របស់ PyCharm៖\n"
        "pip install edge-tts pydub faster-whisper deep-translator\n\n"
        "បើប្រើ Python 3.13 ឬថ្មីជាងនេះ បន្ថែម៖\n"
        "pip install audioop-lts",
    )
    raise SystemExit(1)

# ===================== ការកំណត់ (កែបាន) =====================
VOICES = {
    "ស្រី (Sreymom)": "km-KH-SreymomNeural",
    "ប្រុស (Piseth)": "km-KH-PisethNeural",
}
WHISPER_MODELS = {
    "small  (លឿន)": "small",
    "medium (ត្រឹមត្រូវជាង តែយឺតជាង)": "medium",
}
SAMPLE_RATE = 24000     # គុណភាពសំឡេង Edge TTS
MAX_SPEEDUP = 60        # បើអត្ថបទខ្មែរវែងជាងម៉ោង ឱ្យអានលឿនបំផុត +៦០%
CONCURRENCY = 4         # ចំនួនឃ្លាដែលបង្កើតសំឡេងព្រមគ្នា
TEST_SECONDS = 120      # របៀបសាកល្បង៖ ធ្វើតែ ២ នាទីដំបូងនៃវីដេអូ
FONT = "Khmer UI"       # font អក្សរខ្មែរក្នុង Windows
# ============================================================

NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_ffmpeg(args):
    """ដំណើរការ FFmpeg ហើយប្រគល់ (កូដលទ្ធផល, សារ error)"""
    result = subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"] + args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=NO_WINDOW,
    )
    return result.returncode, result.stderr


def load_clip(path):
    """អានសំឡេង ហើយបំលែងឱ្យមានទម្រង់ដូចគ្នា (mono, 16-bit)"""
    clip = AudioSegment.from_file(path)
    return clip.set_frame_rate(SAMPLE_RATE).set_channels(1).set_sample_width(2)


def silence_bytes(ms):
    """សំឡេងស្ងាត់ប្រវែង ms មីលីវិនាទី"""
    return b"\x00" * (int(SAMPLE_RATE * ms / 1000) * 2)


def srt_time(ms):
    h, rest = divmod(int(ms), 3600000)
    m, rest = divmod(rest, 60000)
    s, milli = divmod(rest, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{milli:03d}"


def write_srt(cues, path):
    """រក្សាទុក subtitle ខ្មែរ"""
    with open(path, "w", encoding="utf-8") as f:
        for n, (start, end, text) in enumerate(cues, start=1):
            f.write(f"{n}\n{srt_time(start)} --> {srt_time(end)}\n{text}\n\n")


async def speak(text, path, voice, rate="+0%"):
    """បង្កើតសំឡេងមួយឃ្លា (ព្យាយាមម្តងទៀតបើបរាជ័យ)"""
    for attempt in range(3):
        try:
            await edge_tts.Communicate(text, voice, rate=rate).save(path)
            return True
        except Exception:
            await asyncio.sleep(1 + attempt)
    return False


class App:
    def __init__(self, root):
        self.root = root
        root.title("Khmer Dub AI — ចិន → ខ្មែរ")
        root.geometry("780x700")
        root.minsize(700, 640)

        self.cancel = threading.Event()
        self.result_path = None

        self.video_var = tk.StringVar()
        self.voice_var = tk.StringVar(value=list(VOICES)[0])
        self.model_var = tk.StringVar(value=list(WHISPER_MODELS)[0])
        self.mode_var = tk.StringVar(value="mix")
        self.vol_var = tk.IntVar(value=15)
        self.test_var = tk.BooleanVar(value=True)
        self.stage_var = tk.StringVar(value="")

        self.build_ui()

    # ------------------------- ផ្ទៃកម្មវិធី -------------------------
    def build_ui(self):
        ttk.Style().configure(".", font=(FONT, 11))
        frame = ttk.Frame(self.root, padding=14)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="១. ជ្រើសវីដេអូដែលនិយាយភាសាចិន").grid(
            row=0, column=0, columnspan=3, sticky="w"
        )
        ttk.Entry(frame, textvariable=self.video_var).grid(
            row=1, column=0, columnspan=2, sticky="ew", pady=(2, 10)
        )
        ttk.Button(frame, text="ជ្រើសរើស...", command=self.pick_video).grid(
            row=1, column=2, padx=(6, 0), pady=(2, 10)
        )

        ttk.Label(frame, text="២. សំឡេង AI ខ្មែរ").grid(row=2, column=0, sticky="w")
        ttk.Combobox(
            frame, textvariable=self.voice_var, values=list(VOICES),
            state="readonly", width=24,
        ).grid(row=2, column=1, sticky="w", pady=(0, 8))

        ttk.Label(frame, text="៣. ម៉ូដែលស្តាប់ភាសាចិន").grid(row=3, column=0, sticky="w")
        ttk.Combobox(
            frame, textvariable=self.model_var, values=list(WHISPER_MODELS),
            state="readonly", width=34,
        ).grid(row=3, column=1, sticky="w", pady=(0, 10))

        mode_box = ttk.LabelFrame(frame, text="៤. សំឡេងក្នុងវីដេអូ", padding=8)
        mode_box.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(0, 10))
        ttk.Radiobutton(
            mode_box, text="លាយជាមួយសំឡេងចិនដើម (សំឡេងចិនតូចៗនៅពីក្រោយ)",
            variable=self.mode_var, value="mix",
        ).pack(anchor="w")
        row = ttk.Frame(mode_box)
        row.pack(anchor="w", padx=(24, 0))
        ttk.Label(row, text="កម្រិតសំឡេងចិនដើម (%)").pack(side="left")
        ttk.Scale(
            row, from_=0, to=100, variable=self.vol_var,
            orient="horizontal", length=220,
        ).pack(side="left", padx=8)
        self.vol_label = ttk.Label(row, text=str(self.vol_var.get()))
        self.vol_label.pack(side="left")
        self.vol_var.trace_add(
            "write", lambda *a: self.vol_label.config(text=str(int(self.vol_var.get())))
        )
        ttk.Radiobutton(
            mode_box, text="ជំនួសសំឡេងចិនទាំងស្រុង",
            variable=self.mode_var, value="replace",
        ).pack(anchor="w", pady=(4, 0))

        ttk.Checkbutton(
            frame,
            text=f"របៀបសាកល្បង (ធ្វើតែ {TEST_SECONDS // 60} នាទីដំបូង — ណែនាំឱ្យសាកល្បងមុនសិន)",
            variable=self.test_var,
        ).grid(row=5, column=0, columnspan=3, sticky="w", pady=(0, 10))

        buttons = ttk.Frame(frame)
        buttons.grid(row=6, column=0, columnspan=3, sticky="w")
        self.start_btn = ttk.Button(buttons, text="ចាប់ផ្តើម", command=self.start)
        self.start_btn.pack(side="left")
        self.cancel_btn = ttk.Button(
            buttons, text="បោះបង់", command=self.on_cancel, state="disabled"
        )
        self.cancel_btn.pack(side="left", padx=6)
        self.open_btn = ttk.Button(
            buttons, text="បើក Folder លទ្ធផល", command=self.open_folder, state="disabled"
        )
        self.open_btn.pack(side="left")

        ttk.Label(frame, textvariable=self.stage_var).grid(
            row=7, column=0, columnspan=3, sticky="w", pady=(10, 0)
        )
        self.progress = ttk.Progressbar(frame, maximum=100)
        self.progress.grid(row=8, column=0, columnspan=3, sticky="ew", pady=6)

        self.log_box = tk.Text(frame, height=10, state="disabled", font=(FONT, 10))
        self.log_box.grid(row=9, column=0, columnspan=3, sticky="nsew")
        frame.rowconfigure(9, weight=1)

    def pick_video(self):
        path = filedialog.askopenfilename(
            title="ជ្រើសវីដេអូ",
            filetypes=[("Video", "*.mp4 *.mkv *.mov *.avi *.webm"), ("All files", "*.*")],
        )
        if path:
            self.video_var.set(path)

    # ------------------------- ជំនួយ (សុវត្ថិភាពជាមួយ thread) -------------------------
    def log(self, message):
        self.root.after(0, self._append_log, message)

    def _append_log(self, message):
        self.log_box.config(state="normal")
        self.log_box.insert("end", message + "\n")
        self.log_box.see("end")
        self.log_box.config(state="disabled")

    def set_progress(self, value):
        self.root.after(0, lambda: self.progress.config(value=value))

    def set_stage(self, text):
        self.root.after(0, lambda: self.stage_var.set(text))

    # ------------------------- ប៊ូតុង -------------------------
    def start(self):
        video = self.video_var.get().strip()
        if not video or not os.path.exists(video):
            messagebox.showwarning("ខ្វះឯកសារ", "សូមជ្រើសឯកសារវីដេអូជាមុន។")
            return
        if not shutil.which("ffmpeg"):
            messagebox.showerror(
                "រកមិនឃើញ FFmpeg",
                "សូមដំឡើង FFmpeg (winget install ffmpeg) ហើយបិទបើក PyCharm ឡើងវិញ។",
            )
            return

        self.cancel.clear()
        self.result_path = None
        self.start_btn.config(state="disabled")
        self.cancel_btn.config(state="normal")
        self.open_btn.config(state="disabled")
        self.progress.config(value=0)
        self.log_box.config(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.config(state="disabled")

        settings = dict(
            video=video,
            voice=VOICES[self.voice_var.get()],
            model_name=WHISPER_MODELS[self.model_var.get()],
            mode=self.mode_var.get(),
            vol=int(self.vol_var.get()),
            test=self.test_var.get(),
        )
        threading.Thread(target=self.job, kwargs=settings, daemon=True).start()

    def on_cancel(self):
        self.cancel.set()
        self.log("កំពុងបោះបង់...")

    def open_folder(self):
        if self.result_path and os.name == "nt":
            os.startfile(os.path.dirname(self.result_path))

    def finish(self):
        self.start_btn.config(state="normal")
        self.cancel_btn.config(state="disabled")
        if self.result_path:
            self.open_btn.config(state="normal")

    # ------------------------- ការងារចម្បង (ដំណើរការក្នុង thread ផ្សេង) -------------------------
    def job(self, video, voice, model_name, mode, vol, test):
        try:
            base = os.path.splitext(video)[0] + ("_khmer_test" if test else "_khmer")

            with tempfile.TemporaryDirectory() as tmp:
                # ជំហាន ១: ទាញសំឡេង
                self.set_stage("ជំហាន ១/៥: កំពុងទាញសំឡេងចេញពីវីដេអូ...")
                wav = os.path.join(tmp, "audio.wav")
                limit = ["-t", str(TEST_SECONDS)] if test else []
                code, err = run_ffmpeg(
                    ["-i", video] + limit + ["-vn", "-ac", "1", "-ar", "16000", wav]
                )
                if code != 0:
                    self.log(f"ទាញសំឡេងមិនបាន: {err.strip()[:300]}")
                    return
                self.set_progress(3)

                # ជំហាន ២: ស្តាប់ភាសាចិន
                self.set_stage("ជំហាន ២/៥: កំពុងស្តាប់ភាសាចិន (យូរជាងគេ)...")
                segments = self.transcribe(wav, model_name)
                if segments is None:
                    self.log("បានបោះបង់។")
                    return
                if not segments:
                    self.log("រកមិនឃើញសំឡេងនិយាយក្នុងវីដេអូទេ។")
                    return
                self.log(f"ស្តាប់ឃើញ {len(segments)} ឃ្លា។")

                # ជំហាន ៣: បកប្រែ
                self.set_stage("ជំហាន ៣/៥: កំពុងបកប្រែចិន → ខ្មែរ...")
                cues = self.translate(segments)
                if cues is None:
                    self.log("បានបោះបង់។")
                    return
                if not cues:
                    self.log("បកប្រែមិនបាន សូមពិនិត្យអ៊ីនធឺណិត។")
                    return

                srt_path = base + ".srt"
                write_srt(cues, srt_path)
                self.log(f"Subtitle ខ្មែររក្សាទុក: {srt_path}")

                # ជំហាន ៤: បង្កើតសំឡេងខ្មែរ
                self.set_stage("ជំហាន ៤/៥: កំពុងបង្កើតសំឡេងខ្មែរ...")
                mp3_path = base + ".mp3"
                ok = asyncio.run(self.make_audio(cues, voice, mp3_path, tmp))
                if not ok:
                    self.log("បានបោះបង់។")
                    return
                self.log(f"សំឡេងខ្មែររក្សាទុក: {mp3_path}")
                self.result_path = mp3_path

                # ជំហាន ៥: ដាក់ចូលវីដេអូ
                self.set_stage("ជំហាន ៥/៥: កំពុងដាក់សំឡេងចូលវីដេអូ...")
                out_path = base + ".mp4"
                if self.merge_video(video, mp3_path, out_path, mode, vol, test):
                    self.result_path = out_path
                    self.log(f"វីដេអូរួចរាល់: {out_path}")
                else:
                    self.log("ដាក់ចូលវីដេអូមិនបានទេ ប៉ុន្តែ MP3 និង .srt នៅតែប្រើបាន។")

            self.set_progress(100)
            self.set_stage("រួចរាល់!")
        except Exception as error:
            self.log(f"មានកំហុស: {error}")
        finally:
            self.root.after(0, self.finish)

    # ---- ជំហាន ២: Whisper ----
    def transcribe(self, wav, model_name):
        self.log(f"កំពុងផ្ទុក model '{model_name}' (លើកដំបូងត្រូវទាញយក ចំណាយពេលបន្តិច)...")
        model = WhisperModel(model_name, device="cpu", compute_type="int8")
        segs, info = model.transcribe(
            wav,
            language="zh",
            beam_size=5,
            vad_filter=True,
            initial_prompt="以下是普通话的句子。",
        )
        total = info.duration or 1
        result = []
        for seg in segs:  # នេះជា generator ដូច្នេះវាស្តាប់បណ្តើរៗ
            if self.cancel.is_set():
                return None
            text = seg.text.strip()
            if text:
                result.append((int(seg.start * 1000), int(seg.end * 1000), text))
            self.set_progress(3 + 42 * min(seg.end / total, 1))
            if len(result) % 20 == 0 and result:
                self.log(f"  ស្តាប់បាន {len(result)} ឃ្លា ({int(seg.end)}/{int(total)} វិនាទី)")
        return result

    # ---- ជំហាន ៣: បកប្រែ ----
    def translate(self, segments):
        total = len(segments)
        results = [None] * total

        def work(i):
            text = segments[i][2]
            for attempt in range(3):
                if self.cancel.is_set():
                    return
                try:
                    out = GoogleTranslator(source="zh-CN", target="km").translate(text)
                    if out and out.strip():
                        results[i] = out.strip()
                        return
                except Exception:
                    time.sleep(1 + attempt)

        done = 0
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(work, i) for i in range(total)]
            for _ in as_completed(futures):
                done += 1
                self.set_progress(45 + 15 * done / total)
        if self.cancel.is_set():
            return None

        failed = sum(1 for r in results if r is None)
        if failed:
            self.log(f"ប្រយ័ត្ន: {failed} ឃ្លាបកប្រែមិនបាន (នឹងរំលង)។")
        return [(s, e, t) for (s, e, _), t in zip(segments, results) if t]

    # ---- ជំហាន ៤: សំឡេងខ្មែរ ----
    async def gen_clip(self, sem, n, text, slot, tmp, voice):
        async with sem:
            if self.cancel.is_set():
                return None
            path = os.path.join(tmp, f"clip_{n}.mp3")
            if not await speak(text, path, voice):
                return None
            clip = load_clip(path)
            if slot > 0 and len(clip) > slot:
                percent = min(int((len(clip) / slot - 1) * 100) + 5, MAX_SPEEDUP)
                if await speak(text, path, voice, rate=f"+{percent}%"):
                    clip = load_clip(path)
            return clip

    async def make_audio(self, cues, voice, out_mp3, tmp):
        total = len(cues)
        done = 0
        sem = asyncio.Semaphore(CONCURRENCY)

        async def one(n):
            nonlocal done
            start, end, text = cues[n]
            next_start = cues[n + 1][0] if n + 1 < total else end
            slot = max(end - start, next_start - start)  # ពេលដែលមានសម្រាប់ឃ្លានេះ
            clip = await self.gen_clip(sem, n, text, slot, tmp, voice)
            done += 1
            self.set_progress(60 + 32 * done / total)
            if done % 20 == 0 or done == total:
                self.log(f"  បង្កើតសំឡេងបាន {done}/{total}")
            return clip

        clips = await asyncio.gather(*(one(n) for n in range(total)))
        if self.cancel.is_set():
            return False

        # តភ្ជាប់សំឡេងតាមម៉ោង (ដាក់ស្ងាត់នៅចន្លោះ កុំឱ្យត្រួតគ្នា)
        parts = []
        current = 0
        failed = 0
        for (start, _end, _text), clip in zip(cues, clips):
            if clip is None:
                failed += 1
                continue
            position = max(start, current)
            if position > current:
                parts.append(silence_bytes(position - current))
            parts.append(clip.raw_data)
            current = position + len(clip)
        if failed:
            self.log(f"ប្រយ័ត្ន: {failed} ឃ្លាបង្កើតសំឡេងមិនបាន (ពិនិត្យអ៊ីនធឺណិត)។")

        track = AudioSegment(
            data=b"".join(parts), sample_width=2, frame_rate=SAMPLE_RATE, channels=1
        )
        track.export(out_mp3, format="mp3", bitrate="128k")
        return True

    # ---- ជំហាន ៥: ដាក់ចូលវីដេអូ ----
    def merge_video(self, video, audio, output, mode, vol, test):
        limit = ["-t", str(TEST_SECONDS)] if test else []

        if mode == "mix":
            v = vol / 100
            graph = (
                f"[0:a]volume={v}[a0];[1:a]volume=1.5[a1];"
                "[a0][a1]amix=inputs=2:duration=first,volume=2[a]"
            )
            code, _err = run_ffmpeg(
                ["-i", video, "-i", audio, "-filter_complex", graph,
                 "-map", "0:v", "-map", "[a]",
                 "-c:v", "copy", "-c:a", "aac", "-b:a", "192k"] + limit + [output]
            )
            if code == 0:
                return True
            self.log("លាយសំឡេងមិនបាន → ប្រើការជំនួសសំឡេងវិញ")

        code, err = run_ffmpeg(
            ["-i", video, "-i", audio, "-map", "0:v", "-map", "1:a",
             "-c:v", "copy", "-c:a", "aac", "-b:a", "192k"] + limit + [output]
        )
        if code != 0:
            self.log(f"FFmpeg error: {err.strip()[:400]}")
        return code == 0


if __name__ == "__main__":
    window = tk.Tk()
    App(window)
    window.mainloop()
